# LAN Arena

A multiplayer game arena for LAN parties and competitive play. Features reaction tests, strategy games (Tic-Tac-Toe, Connect Four, Checkers, Battleship), memory challenges, puzzles, and more.

## Live Demo (GitHub Pages)

The static frontend is published via GitHub Pages. Multiplayer requires a running Socket.IO backend; without it the UI loads in offline mode.

## Structure

```
.
├── index.html          # App entry
├── css/base.css        # Styles
├── js/
│   ├── main.js         # Client logic, Socket.IO client
│   └── games.js        # Client-side game renderers
└── server/games/       # Authoritative game logic modules
    ├── registry.js
    ├── reaction-test.js
    ├── tic-tac-toe.js
    └── ... (15 games)
```

## Games included

- **Reaction**: Reaction Test, Color Rush, Fast Fingers, Quick Draw
- **Strategy**: Tic-Tac-Toe, Connect Four, Checkers, Battleship
- **Memory**: Number Flash, Memory Cards, Pattern Master, Sequence Master
- **Puzzle / Competitive**: Word Scramble, Math Duel, Speed Typing

## Running locally (full stack)

This repository contains the frontend and the pure game-logic modules. You still need a Node.js + Socket.IO server that:

1. Serves the static files
2. Uses the modules under `server/games/`
3. Handles auth, rooms, matchmaking, and the game loop (tick + actions)

Point the Socket.IO client at your server (or host the static files from the same origin).

## GitHub Pages

1. Push this repository to GitHub
2. Settings → Pages → Source: Deploy from a branch → `main` / root
3. The site will be available at `https://<user>.github.io/<repo>/`

Absolute paths were converted to relative so the site works both at the domain root and under a project path.

## License

MIT (or as you prefer)
